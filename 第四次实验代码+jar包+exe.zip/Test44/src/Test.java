import java.io.*;
import java.util.*;

public class Test {
    public static void main(String[] args) throws IOException {

        InputStreamReader reader = new InputStreamReader(new FileInputStream(args[0]), "UTF-8");
        BufferedReader br = new BufferedReader(reader);

        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(args[1]), "UTF-8");
        BufferedWriter bw = new BufferedWriter(writer);

        HashMap<String,Integer> pro = new HashMap<>();//<省，每个省份总数>
        HashMap<String,Integer> city = new HashMap<>();//<市，每个市的数量>
        HashMap<String,HashMap> total = new HashMap<>();//<省，市和每个市的数量>

        int n = 0;
        String title="";
        String tmp="";
        while((tmp = br.readLine())!= null) {
            if (tmp.contains("待明确地区"))continue;
            String head = tmp.substring(0,3);
            String msg = tmp.substring(3).trim();
            if (title.equals(head)!=true){
                if (title!=""){
                    total.put(title,city);
                    pro.put(title,n);
                    n = 0;
                    city = new HashMap<>();
                }
            }
            city.put(msg.substring(0,msg.indexOf('\t')),Integer.parseInt(msg.substring(msg.indexOf('\t')).trim()));
            n += Integer.parseInt(msg.substring(msg.indexOf('\t')).trim());
            title = head;
        }
        total.put(title,city);
        pro.put(title,n);
        List<Map.Entry<String,Integer>> list_province = new ArrayList<>(pro.entrySet());
        list_province.sort(new Comparator<Map.Entry<String, Integer>>() {//通过比较器按数量进行排序
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o2.getValue().compareTo(o1.getValue());
            }
        });

        for(int i = 0 ;i < list_province.size();i++){
            bw.write(list_province.get(i).getKey() + "\t" + list_province.get(i).getValue() + "\r\n");
            bw.flush();
            List<Map.Entry<String ,Integer>> list_city = new ArrayList<>(total.get(list_province.get(i).getKey()).entrySet());
            list_city.sort(new Comparator<Map.Entry<String, Integer>>() {
                @Override
                public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });
            for(int j = 0;j < list_city.size();j++){
                bw.write(list_city.get(j).getKey() + "\t" + list_city.get(j).getValue() + "\r\n");
                bw.flush();
            }
            bw.write("\r\n");
            bw.flush();
        }
        reader.close();
        br.close();
        writer.close();
        bw.close();
    }
}



