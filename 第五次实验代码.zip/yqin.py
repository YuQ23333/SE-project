import argparse
import sys
reload(sys)
sys.setdefaultencoding('utf8')
import copy


def dicFromFile():
    filename = lines[0]
    file = open(filename, "r")
    fList = list(file)
    file.close()
    In= {}
    for i in fList:
        iList = i.split('\t')
        province = iList[0]
        place = iList[1]
        count = int(iList[2][0:-1])
        if province in In:
            In[province][place] = count
        else:
            In[province] = {}
            In[province][place] = count
    return In


def provinceCount(province):
    count = 0
    for i in province:
        count += int(province[i])
    return count

def takeSecond(elem):
    return elem[1]

def listSort(list):
    list2=copy.deepcopy(list)
    result = []
    while list2 != []:
        max = list2[0]
        for i in list2:
            place = i[0]
            count = i[1]
            if count < max[1]:
                max = i
            elif count == max[1]:
                if place.encode('gb2312') > max[0].encode('gb2312'):
                    max = i
        #print("max", max)
        result.insert(0, max)
        list2.remove(max)
    return result

def provinceList(dic):
    list = []
    for i in dic:
        count = provinceCount(dic[i])
        list.append((i, count))
    #max = list[0]
    result = listSort(list)
    return result

def placeList(province):
    list = []
    for i in province:
        count = province[i]
        list.append((i, count))
    result = listSort(list)
    return result

def writeFile(x):
    filename=lines[1]
    file=open(filename,'w')
    count = len(lines)
    if (count <=2):
        s = ""
        province = provinceList(x)
        for i in province:
            s += "{} {}\n".format(i[0], i[1])
            place = placeList(x[i[0]])
            # print("place: ", place)
            for j in place:
                # print("place element: ", i)
                s += "{} {}\n".format(j[0], j[1])
            s += "\n"
        #print(s)
        file.write(s)
    else:
        s = " "
        condition = lines[2]
        shengshi = str(condition)
        province = provinceList(x)
        for i in province:
            if i[0] == shengshi:
                s += "{}{}\n".format(shengshi, i[1])
                place = placeList(x[i[0]])
                for j in place:
                    s += "{}{}\n".format(j[0], i[0])
                s += "\n"
        file.write(s)

def Main():
    global lines
    lines =raw_input().split(' ')
    x=dicFromFile()
    writeFile(x)


if __name__ == "__main__":
    Main()

    # all = dicFromFile("yq_in04.txt")


