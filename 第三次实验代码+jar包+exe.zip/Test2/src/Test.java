import java.io.*;
import java.util.Scanner;

public class Test {
    public static void main(String[] args) throws IOException {
        String sf = null;
        if (args.length > 2){
            sf = args[2];
        }

        InputStreamReader reader = new InputStreamReader(new FileInputStream(args[0]),"UTF-8");
        BufferedReader br = new BufferedReader(reader);

        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream(args[1]),"UTF-8");
        BufferedWriter bw = new BufferedWriter(writer);

        String title="";
        String tmp="";
            while((tmp = br.readLine())!= null) {
                if (tmp.contains("待明确地区"))continue;
                String head = tmp.substring(0,3);
                String msg = tmp.substring(3);
                if (sf!= null && ! sf.equals(head)) {
                    continue;
                }
                if (title.equals(head)!=true){
                    if (title!=""){
                        bw.write("\n");
                    }
                    bw.write(head.substring(0,3)+"\n");
                    title = head;
                }

                bw.write(msg.trim()+"\n");
                bw.flush();

                }

        reader.close();
        br.close();
        writer.close();
        bw.close();
    }
}


