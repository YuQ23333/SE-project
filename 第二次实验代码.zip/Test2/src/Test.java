import java.io.*;

public class Test {
    public static void main(String[] args) throws IOException {
        //按行读中文文档
        InputStreamReader reader = new InputStreamReader(new FileInputStream("D:\\SEProject\\yq_in.txt"),"GBK");
        BufferedReader br = new BufferedReader(reader);

        //按行写入，也就是变相的分行打印
        OutputStreamWriter writer = new OutputStreamWriter(new FileOutputStream("D:\\SEProject\\yq_out.txt"),"GBK");
        BufferedWriter bw = new BufferedWriter(writer);

        //设置空字符串，对格式进行调整
        String title="";
        String tmp="";
            while((tmp = br.readLine())!= null) {
                if (tmp.contains("待明确地区"))continue;//可观察到in.txt文件中去除了“待明确地区”的数据，这里进行剔除
                String head = tmp.substring(0,3);//用substring方法分离省份
                String msg = tmp.substring(3);//分离省份之后的详细数据
                if (title.equals(head)!=true){
                    if (title!=""){
                        bw.write("\n");
                    }
                    bw.write(head.substring(0,3)+"\n");
                    title = head;
                }
                bw.write(msg.trim()+"\n");
                bw.flush();
        }
        reader.close();
        br.close();
        writer.close();
        bw.close();
    }
}


